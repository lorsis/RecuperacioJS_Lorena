document.addEventListener("DOMContentLoaded", main);
let schedules = [];
let playlists = [];

function main() {
    carregarjson();
    const tbody = document.querySelector("tbody");
    const botonGrabar = document.querySelector("#Guardar");
    botonGrabar.addEventListener("click",guardar);
}

function carregarjson() {
    fetch("./data/data.json")
        .then(res => res.json())
        .then(data => {

            localStorage.setItem("schedules", JSON.stringify(data));
            console.log("Data loaded:", data);

        });
}
function carregarjsonPlaylists() {
    fetch("./data/data.json")
        .then(res => res.json())
        .then(data => {
            console.log("Data loaded:", data);

            localStorage.setItem("playlists", JSON.stringify(data));
        });
}

function insertarFila(schedules) {
    const fila = document.createElement("tr");
    // id
    const tdId = document.createElement("td");
    ponerTexto(tdId, schedules.concepto
    );
    // nom
    const tdNom = document.createElement("td");
    //hora
    const tdHora = document.createElement("td");
    ponerTexto(
        tdHora,
        formatearHora(schedules.hora)
    );
    // segons
    const tdSegs = document.createElement("td");
    ponerTexto(
        tdSegs, schedules.segns
    );
    // cancion
    const tdCancion = document.createElement("td");
    ponerTexto(
        tdCancion,
        obtenerTipo(schedules)
    );
    let editar = document.createElement("button");
    let textEditar = document.createTextNode("Editar");
    editar.appendChild(textEditar);
    tr.appendChild(editar);
    editar.addEventListener("click", () => {
        carregarFormulariEditar(c.id);
    });

 R
    const tdBorrar = document.createElement("td");
    const botonBorrar = document.createElement("button");
    ponerTexto(botonBorrar, "Borrar");
    botonBorrar.addEventListener("click", () => {
        borrar(indice);
    });
    tdBorrar.appendChild(botonBorrar);


    fila.appendChild(tdId);
    fila.appendChild(tdNom);
    fila.appendChild(tdHora);
    fila.appendChild(tdSegs);
    fila.appendChild(tdCancion)
    fila.appendChild(tdBorrar);
    tbody.appendChild(fila);
}

function guardar(schedules) {
    if (!validarFormulario()) {
        return;
    }
    const programaTimbre = {
        nombre: inputConcepto.value,
        hora: inputHora.value,
        segs: inputSegs.value,
        cancion: timeSongSelect.value
    };
    schedules.push(nuevo);
    guardarEnLocalStorage();
    if (schedules.length === 1) {
        limpiarElemento(tbody);
    }
    limpiarFormulario();
}

function borrar(schedules, id) {
    const confirmar = confirm("¿Seguro que quieres borrar el apunte?");
    if (!confirmar) {
        return;
    }
    schedules.splice(id, 1);
    guardarEnLocalStorage();
    carregarjson();
}

function guardarEnLocalStorage(schedules) {
    localStorage.setItem(
        "contingut",
        JSON.stringify(schedules)
    );
}

function limpiarFormulario() {
    inputConcepto.value = "";
    inputHora.value = "";
    inputSegs.value = "";
    timeSongSelect.value = "";
}

function limpiarElemento(elemento) {
    elemento.replaceChildren();
}
